package com.example.button;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class educationaldetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educationaldetails);
    }
}